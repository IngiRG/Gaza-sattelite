GAZA SENTINEL-2 COMPARISON V2

DEPLOY
1. Open https://app.netlify.com/drop
2. Upload this ZIP.
3. Open the generated HTTPS address.

CHANGES
- Uses standards-compliant STAC GET requests.
- Does not use sortby, query extensions, open-ended dates, or POST.
- Renders each COG directly in the browser using GeoRaster.
- Verifies scene IDs and visual asset URLs differ.

The first load can take longer on a phone because two GeoTIFFs are read by HTTP range requests.
